javascript-rsa
==============

RSA encryption with javascript

* relies on jsbn library from Tom Wu
  http://www-cs-students.stanford.edu/~tjw/jsbn/

Security
--------

This is a pet project done a long time ago just for fun. In general, don't do cryptography in javascript, see:
<http://www.matasano.com/articles/javascript-cryptography/>
